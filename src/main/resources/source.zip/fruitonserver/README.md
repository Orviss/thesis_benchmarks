# Fruitons server
Backend for Fruitons game.

## How to run

```
mvn package
cd target
java -jar fruiton-server-1.0-SNAPSHOT.jar
```

## Requirements
* Java 9
* MongoDB