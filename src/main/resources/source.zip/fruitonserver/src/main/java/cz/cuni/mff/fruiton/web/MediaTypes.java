package cz.cuni.mff.fruiton.web;

public final class MediaTypes {

    public static final String PROTOBOUF = "application/x-protobuf";

    private MediaTypes() {

    }

}
