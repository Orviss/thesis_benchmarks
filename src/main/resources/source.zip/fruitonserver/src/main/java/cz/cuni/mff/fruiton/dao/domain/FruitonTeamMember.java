package cz.cuni.mff.fruiton.dao.domain;

public class FruitonTeamMember {

    private int fruitonId;

    private int x;

    private int y;

    public final int getFruitonId() {
        return fruitonId;
    }

    public final void setFruitonId(final int fruitonId) {
        this.fruitonId = fruitonId;
    }

    public final int getX() {
        return x;
    }

    public final void setX(final int x) {
        this.x = x;
    }

    public final int getY() {
        return y;
    }

    public final void setY(final int y) {
        this.y = y;
    }
}
